

class Dept:
    def __init__(self, dcode, dname):
        self.dcode = dcode
        self.dname = dname

    def get_dept(self):
        return self.dcode, self.dname


class EmpSal:
    def __init__(self, eid, esal):
        self.eid = eid
        self.esal = esal

    def get_Emp(self):
        return self.eid, self.esal


class EmpDetails(Dept, EmpSal):
    def __init__(self, fname, lname, eid,esal,dcode,dname):
        Dept.__init__(self,dcode,dname)
        EmpSal.__init__(self, eid,esal)
        self.fname = fname
        self.lname = lname

    def get_Emp(self):
        return self.eid, self.fname, self.lname, self.esal, self.dcode, self.dname

eid = "0012"
fname = 'ravender'
lname = 'rana'
sal = 3000
dcode = 121
dname = 'IT'

out = EmpDetails(eid,fname,lname,sal,dcode,dname)
print(out.get_Emp())


