import time

def get_time(fun): # Decorator function
    def time_map(*args, **kwargs):
        start = time.time()
        result = fun(*args, **kwargs)
        end = time.time()
        print(fun.__name__ + ' took ' + str(round(((end - start)*1000), 2)) + ' millisecond')
        return result
    return time_map


@get_time # Decorator
def calc_square(nums):
    res = []
    for num in nums:
        res.append(num * num)
    return res

@get_time # Decorator
def calc_cube(nums):
    res = []
    for num in nums:
        res.append(num * num * num)
    return res


arr = range(1, 1000000)
cube = calc_cube(arr)
square = calc_square(arr)


