from abc import ABC, abstractmethod

class classDetail(ABC):
    def __init__(self, sname, sroll):
        self.sname = sname
        self.sroll = sroll

    @abstractmethod
    def get_fee(self):
        pass


    def stu_details(self):
        return f"{self.sname} {self.sroll}"


class s_details(classDetail):
    def __init__(self,sname,sroll,sfee):
        super().__init__(sname,sroll)
        self.sfee = sfee

    def get_fee(self):
        return self.sfee


sname = 'Ravender'
sroll = '190209572'
sfee = 4000
a = s_details(sname, sroll, sfee)
print(a.sname)
print(a.sroll)
print(a.sfee)

