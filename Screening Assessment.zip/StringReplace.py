import re


input_file = open('Input.txt')

def StrReplace(string, input_str: str, replace_str: str):
    """
    This function will replace the input string to the replace string
    """

    try:
        return re.sub(input_str, replace_str, string.lower())
    except Exception as e:
        return e



input_str = "placement"
replace_str = "screening"

for i in input_file:
    print(StrReplace(i, input_str, replace_str))